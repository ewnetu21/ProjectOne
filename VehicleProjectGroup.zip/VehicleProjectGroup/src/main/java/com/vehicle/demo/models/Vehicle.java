package com.vehicle.demo.models;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Vehicle {
@Id
@GeneratedValue
	
		// TODO Auto-generated constructor stub
		private int vehicleID;
		private String make;
		private String model;
		private String color;
		@OneToMany(mappedBy="moterist")
        private Set<Moterist> moterist;
		@ManyToOne
		@JsonIgnore
		private Set<Accident> accident;
		public int getVehicleID() {
			return vehicleID;
		}
		public void setVehicleID(int vehicleID) {
			this.vehicleID = vehicleID;
		}
		public String getMake() {
			return make;
		}
		public void setMake(String make) {
			this.make = make;
		}
		public String getModel() {
			return model;
		}
		public void setModel(String model) {
			this.model = model;
		}
		public String getColor() {
			return color;
		}
		public void setColor(String color) {
			this.color = color;
		}
		public Set<Moterist> getMoterist() {
			return moterist;
		}
		public void setMoterist(Set<Moterist> moterist) {
			this.moterist = moterist;
		}
		public Set<Accident> getAccident() {
			return accident;
		}
		public void setAccident(Set<Accident> accident) {
			this.accident = accident;
		}
		
		
}
