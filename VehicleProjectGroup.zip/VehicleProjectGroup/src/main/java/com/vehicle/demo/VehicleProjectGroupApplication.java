package com.vehicle.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VehicleProjectGroupApplication {

	public static void main(String[] args) {
		SpringApplication.run(VehicleProjectGroupApplication.class, args);
	}

}
