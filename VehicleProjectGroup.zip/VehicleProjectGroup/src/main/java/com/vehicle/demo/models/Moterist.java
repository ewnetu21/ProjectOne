package com.vehicle.demo.models;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
public class Moterist {
@Id
@GeneratedValue
		// TODO Auto-generated constructor stub
		private String Fname;
		private String Lname;
		private String licence;
		private int age;
		@ManyToOne
		@JsonIgnore
		private Vehicle vehicle;
		//@ManyToOne
		//@JsonIgnore
		private Accident accident;
		
		public String getFname() {
			return Fname;
		}
		public void setFname(String fname) {
			Fname = fname;
		}
		public String getLname() {
			return Lname;
		}
		public void setLname(String lname) {
			Lname = lname;
		}
		public String getLicence() {
			return licence;
		}
		public void setLicence(String licence) {
			this.licence = licence;
		}
		public int getAge() {
			return age;
		}
		public void setAge(int age) {
			this.age = age;
		}
		public Vehicle getVehicle() {
			return vehicle;
		}
		public void setVehicle(Vehicle vehicle) {
			this.vehicle = vehicle;
		}
		public Accident getAccident() {
			return accident;
		}
		public void setAccident(Accident accident) {
			this.accident = accident;
		}
		
		
}