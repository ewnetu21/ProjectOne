package com.vehicle.demo.models;

import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Accident {

	
		@Id
		@GeneratedValue
		// TODO Auto-generated constructor stub
		 private int accidentId;
		 private String accidentAddress;
		 @OneToMany(mappedBy="vehicle")
	     private Set<Vehicle> vehicle;
		@OneToMany(mappedBy="moterist")
	     private Set<Moterist> moterist;
		public int getAccidentId() {
			return accidentId;
		}
		public void setAccidentId(int accidentId) {
			this.accidentId = accidentId;
		}
		public String getAccidentAddress() {
			return accidentAddress;
		}
		public void setAccidentAddress(String accidentAddress) {
			this.accidentAddress = accidentAddress;
		}
		public Set<Vehicle> getVehicle() {
			return vehicle;
		}
		public void setVehicle(Set<Vehicle> vehicle) {
			this.vehicle = vehicle;
		}
		public Set<Moterist> getMoterist() {
			return moterist;
		}
		public void setMoterist(Set<Moterist> moterist) {
		this.moterist = moterist;
		}
	

}
