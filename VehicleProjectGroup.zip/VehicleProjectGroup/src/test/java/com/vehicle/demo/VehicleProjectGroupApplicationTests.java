package com.vehicle.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VehicleProjectGroupApplicationTests {

	@Test
	void contextLoads() {
	}

}
